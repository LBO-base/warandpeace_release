@echo off
chcp 65001 >nul
REM === War and Peace updater ===
REM Кладётся вместе с содержимым "В-ПАПКУ-ИГРЫ" в корень папки Valheim.
REM Качает свежий мод с сервера разработки и подменяет DLL. Игра должна быть ЗАКРЫТА!

set URL=https://raw.githubusercontent.com/LBO-base/warandpeace_release/main/latest
set DEST=%~dp0BepInEx\plugins\WarAndPeace

REM Piece -> Peace migration: rename old mod folder, drop old DLL
if exist "%~dp0BepInEx\plugins\WarAndPiece" (
  if not exist "%DEST%" move "%~dp0BepInEx\plugins\WarAndPiece" "%DEST%" >nul
  del /q "%DEST%\WarAndPiece.dll" 2>nul
)

echo === War and Peace: обновление мода ===
if not exist "%DEST%" (
  echo [!] Не найдена папка %DEST%
  echo     Этот файл должен лежать в КОРНЕ папки Valheim - рядом с valheim.exe.
  pause
  exit /b 1
)

curl -s -f -o "%TEMP%\wap_version.txt" %URL%/version.txt
if errorlevel 1 (
  echo [!] Сервер обновлений недоступен. Попробуй позже.
  pause
  exit /b 1
)
set /p VER=<"%TEMP%\wap_version.txt"
echo Доступная версия: %VER%
echo Скачиваю...

curl -s -f -o "%DEST%\WarAndPeace.dll.new" %URL%/WarAndPeace.dll
if errorlevel 1 (
  echo [!] Ошибка скачивания.
  pause
  exit /b 1
)
if exist "%DEST%\WarAndPeace.dll" move /y "%DEST%\WarAndPeace.dll" "%DEST%\WarAndPeace.dll.bak" >nul
move /y "%DEST%\WarAndPeace.dll.new" "%DEST%\WarAndPeace.dll" >nul

echo.
echo [OK] Установлена версия %VER%. Запускай игру!
echo      (прежняя DLL сохранена как WarAndPeace.dll.bak)
pause
