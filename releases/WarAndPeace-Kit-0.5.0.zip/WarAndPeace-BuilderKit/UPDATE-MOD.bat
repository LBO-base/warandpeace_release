@echo off
REM === War and Peace updater (English) ===
REM Place together with the contents of "В-ПАПКУ-ИГРЫ" in your Valheim root folder.
REM Downloads the latest build and swaps the DLL. The game must be CLOSED!

set URL=https://raw.githubusercontent.com/LBO-base/warandpeace_release/main/latest
set DEST=%~dp0BepInEx\plugins\WarAndPeace

REM Piece -> Peace migration: rename old mod folder, drop old DLL
if exist "%~dp0BepInEx\plugins\WarAndPiece" (
  if not exist "%DEST%" move "%~dp0BepInEx\plugins\WarAndPiece" "%DEST%" >nul
  del /q "%DEST%\WarAndPiece.dll" 2>nul
)

echo === War and Peace: updating the mod ===
if not exist "%DEST%" (
  echo [!] Folder not found: %DEST%
  echo     This file must sit in the ROOT of your Valheim folder - next to valheim.exe.
  pause
  exit /b 1
)

curl -s -f -o "%TEMP%\wap_version.txt" %URL%/version.txt
if errorlevel 1 (
  echo [!] Update server unreachable. Try again later.
  pause
  exit /b 1
)
set /p VER=<"%TEMP%\wap_version.txt"
echo Available version: %VER%
echo Downloading...

curl -s -f -o "%DEST%\WarAndPeace.dll.new" %URL%/WarAndPeace.dll
if errorlevel 1 (
  echo [!] Download failed.
  pause
  exit /b 1
)
if exist "%DEST%\WarAndPeace.dll" move /y "%DEST%\WarAndPeace.dll" "%DEST%\WarAndPeace.dll.bak" >nul
move /y "%DEST%\WarAndPeace.dll.new" "%DEST%\WarAndPeace.dll" >nul

echo.
echo [OK] Version %VER% installed. Start the game!
echo      (the previous DLL is kept as WarAndPeace.dll.bak)
pause
