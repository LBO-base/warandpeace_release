# War and Peace — install (English)

*Русская версия: [README.ru.md](README.ru.md). Builders guide: [BUILDER-GUIDE.md](BUILDER-GUIDE.md).*

Living faction wars for Valheim: 150+ settlements trade, march armies and
besiege each other — and you can found your own town.

## Install
1. Open the folder **«В-ПАПКУ-ИГРЫ»** (it means "into the game folder").
2. Move its **contents** into your Valheim root folder — next to `valheim.exe`
   (BepInEx is included).
3. Copy `UPDATE-MOD.bat` there too.
4. Start the game.

## Update
Run `UPDATE-MOD.bat` in the Valheim folder **with the game closed** — it
downloads the latest build from GitHub.

## Multiplayer
The mod must be installed on the server AND on every client, same version.
Docs & news: https://github.com/LBO-base/warandpeace_release
