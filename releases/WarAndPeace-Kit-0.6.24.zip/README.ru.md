# War and Peace — установка (по-русски)

*English: [README.md](README.md). Строителям: [BUILDER-GUIDE.ru.md](BUILDER-GUIDE.ru.md).*

Живой мир фракций для Valheim: 150+ поселений торгуют, водят армии и осаждают
друг друга — а ты можешь основать своё.

## Установка
1. Открой папку **«INTO-GAME-FOLDER»**.
2. Перенеси её **содержимое** в корень Valheim — рядом с `valheim.exe`
   (BepInEx уже внутри).
3. Скопируй туда же `UPDATE-MOD-RU.bat`.
4. Запусти игру.

## Обновление
Запусти `UPDATE-MOD-RU.bat` в папке Valheim **при закрытой игре** — он скачает
свежий билд с GitHub.

## Мультиплеер
Мод обязателен на сервере И на всех клиентах, версии должны совпадать.
Дока и новости: https://github.com/LBO-base/warandpeace_release
